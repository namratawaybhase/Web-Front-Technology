<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<title><?php echo $mega_title ?></title>
	</head>
	<body style="text-align:left;color:blue;">
		<H1>Page B</H1>
		<HR></HR>
		<div style="float:left" >
			Since : <?php echo $since; ?> past <?php echo $past; ?> years
		</div>
		<div style="clear:both;"></div>
		<HR></HR>
		<?php echo anchor('home_page', 'Back to Home Page') ?>
	</body>
</html> 