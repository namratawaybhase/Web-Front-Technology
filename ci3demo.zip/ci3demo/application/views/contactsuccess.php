<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Contact sent</title>
    </head>
    <body>

        <div id="container">	
            <div id="body">
                <p><?php echo $message ?></p>
            </div>

        </div>
    </body>
</html>