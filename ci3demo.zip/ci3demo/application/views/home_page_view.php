<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<title><?php echo $mega_title ?></title>
		<?PHP
		/* data from controller
		  $email, $email_valid, $url, $url_valid , $url_exist
		 */
		$validation_text = ($email_valid) ? "Is Valid " : "Is Not Valid!";
		$validation_url = ($url_valid) ? "Is Valid " : "Is Not Valid!";
		$exist_url = ($url_exist) ? "Exist " : "Not exist!";
		?>
	</head>
	<body style="text-align: left; color: blue;">
		<H1>Main Page</H1>
		<HR></HR>
		<div style = "float: left">
			The Email: <?php echo $email_valid; ?><?php echo $validation_text; ?>
		</div>
		<div style = "clear: both;"></div>
		<HR>
		<div>
			The url: <?php echo $url; ?><?php echo $validation_url; ?> and <?php echo $exist_url; ?>
			<?php echo anchor ($url, '[visit the url]', array ("target" => "_blank", "title" => "opens a new
			Tab")); ?>
		</div>
		<div style = "clear: both;"></div>
		<HR>
		<?php echo anchor('home_page/page_b', 'Navigate me to page B') ?>
	</body>
</html>