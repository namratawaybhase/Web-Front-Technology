<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title><?php echo $mega_title ?></title>
    </head>
    <body>
        <table>
            <tr>
                <td>ISBN</td>
                <td>Book Title</td>
                <td>Book Price</td>
            </tr>
            <?php foreach ($books as $book): ?>
                <tr>
                    <td><?php echo $book->isbn ?></td>
                    <td><?php echo $book->bookTitle; ?></td>
                    <td><?php echo $book->bookPrice; ?></td>
                </tr>
            <?php endforeach; ?>

    </body>
</html>