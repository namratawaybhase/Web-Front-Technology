<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title><?php echo $mega_title ?></title>
    </head>
    <body>
        <div id="container">
            <h1><?php echo $title ?></h1>

            <div id="body">
                <p><?php echo $message ?></p>
            </div>
        </div>
    </body>
</html>