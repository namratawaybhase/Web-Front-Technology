<!DOCTYPE html">
<html>
	<head>
		<script src="http://code.jquery.com/jquery-3.3.1.min.js"></script>
		<script type='text/javascript'>
			// The user to call the Ajax handler controller 
			var saveUserFeedbackLink = '<?php echo site_url('feedback_handler/saveUserFeedback') ?>';
			var getUserFeedbacksLink = '<?php echo site_url('feedback_handler/getUserFeedbackLog') ?>';
			$(document).ready(function () {
				// When user click for a feedback popup feedback window :
				$('#userIdeas').click(function () {
					var feedback = $('#userFeedback').val();
					$.post(
						saveUserFeedbackLink,
						{feedback: feedback},
						function(result){
							$('#message').html('Your feedback Updated - Thanks!');
						}
					);
				});
				$('#feedbackLog').click(function () {
					$.get(
						getUserFeedbacksLink,
						{},
						function(data){
							$('#feedbackLogView').html(data);
						}
					);
				});
			});
		</script>
	</head>
	<body>
		<h1> Welcome <?= $user_name; ?>! </h1>
		<h1> You are logged in! </h1>
		<hr>
		<h3> Your User ID is: 	<?php echo $uid; ?> </h3>
		<h3> Your System Role is :<?php echo $role; ?> </h3>
		<h3> Your Menu options  :<?php echo $menu; ?> </h3>
		<h2>
			<?php echo anchor('auth/logout', 'Logout') ?>
		</h2>
		<hr>
		<button id = 'userIdeas'>Add A New Feedback</button><br>
		<div>
			<fieldset>
				<span id = "userName"> Thanks <?php echo $user_name; ?>, Please share your feedback with us </span><br>
				<textarea name = "idea_desc" id = "userFeedback"  rows = "10" cols = "83" placeholder = 'Your idea/Improvement Suggestion...'> </textarea>
			</fieldset>
		</div>
		<div id = 'message'>
		</div>
		<hr>
		<button id = "feedbackLog">See Your Feedback Log</button><br>
		<div id = 'feedbackLogView'>
		</div>
	</body>
</html>
