<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Book extends CI_Controller {
    function __construct() {
        parent::__construct();
    }

    public function books() {

        // Manualy loading the database
        $this->load->database();

        // Loading the model class
        $this->load->model('Bookmodel');

        $view_params['mega_title'] = 'Book Model';

        // Calling the model to retrieve the books from the database
        $view_params['books'] = $this->Bookmodel->get_books();

        $this->load->view('bookview', $view_params);
    }

}
