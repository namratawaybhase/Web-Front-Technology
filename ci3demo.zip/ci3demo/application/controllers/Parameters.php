<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Parameters extends CI_Controller {

    function __construct() {
        parent::__construct();
    }

    public function show($a, $b, $c) {
        $rows = array('a' => $a, 'b' => $b, 'c' => $c);

        $view_params = array(
            'mega_title' => 'Passing parameters to view', 
            'rows' => $rows);
        $this->load->view('show_parameters', $view_params);
    }

}
