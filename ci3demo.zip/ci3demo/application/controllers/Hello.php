<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Hello extends CI_Controller {
    function __construct() {
        parent::__construct();
    }

    public function index() {
        $view_params = array(
            'mega_title' => 'Codeigniter - Hello World', 
            'title' => 'Welcome to Codegniter', 
            'message' => "Hello World");

        $this->load->view('helloview', $view_params);
    }
}
