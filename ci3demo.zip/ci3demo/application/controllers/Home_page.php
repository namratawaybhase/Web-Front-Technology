<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Home_page extends CI_Controller {

	function __construct() {
		parent::__construct();
		// Loading the form_validation library
		$this->load->library('form_validation');
		$this->load->helper('date');
		$this->load->helper('url');
	}

	public function index() {
		$data = array();
		$data ['email'] = $email = "the@email.com";
		$data ['email_valid'] = $email;
		$data ['url'] = $url = "http://cnn.com";
		$data ['url_valid'] = $url;
		$data ['url_exist'] = $url;
		$this->load->view('home_page_view', $data);
	}

	public function page_b() {
		$data = array();
		$myqsl_date = "1970-01-01";
		// dates_time_helper calls
		$data ['since'] = $myqsl_date;
		$now = time();
		$data ['past'] = timespan($myqsl_date, $now);
		//$data ['past'] = getAgeAccurate ($myqsl_date, $percision = 2);
		$this->load->view('page_b_view', $data);
	}

}

// End controller