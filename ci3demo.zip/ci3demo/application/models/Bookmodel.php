<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Bookmodel extends CI_Model {

    public function __construct() {
        // Call the Model constructor
        parent::__construct();
    }

    public function get_books() {
        $query = $this->db->get('books');

        return $query->result();
    }

}
