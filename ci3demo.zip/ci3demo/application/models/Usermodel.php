<?php

class Usermodel extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    function check_login($user, $pass) {
        //	id 	user_name 	password
        $sql = "SELECT * FROM   users
			 WHERE  user_name = '$user'  
			 AND    password  = '$pass' ";

        $q = $this->db->query($sql);

        if ($q->num_rows()) {
            foreach ($q->result() as $row)
                return $row;
        }
        return NULL;
    }

    function get_logged_in_user() {
        // Will check if there's a login user asession and if so will fetch its record 	

        /// get the loogin in uid if any :
        $uid = $this->session->userdata('user_id');

        if (!$uid)
            return NULL;

        $sql = "SELECT *  FROM   users
			WHERE  id = '$uid'";

        $q = $this->db->query($sql);

        if ($q->num_rows()) {
            foreach ($q->result() as $row)
                return $row;
        }
        return NULL;
    }

    function get_user_rec($uid) {
        // Will check if there's a login user asession and if so will fetch its record 	
        /// get the loogin in uid if amy :

        if (!$uid)
            return NULL;

        $sql = "SELECT *  FROM   users
				WHERE  id = '$uid'";

        $q = $this->db->query($sql);

        if ($q->num_rows()) {
            foreach ($q->result() as $row)
                return $row;
        }
        return NULL;
    }

    function keep_user_feedback($feedback) {

        $uid_rec = $this->get_logged_in_user();
        $uid = $uid_rec ? $uid_rec->id : 0;
        print_r($uid);
        /* id 	email  	uid feedback timestamp 	
         */
        $table = 'user_feedback';
        $data = array('feedback' => urldecode($feedback),
            'uid' => $uid
        );
        $this->db->insert($table, $data);
    }

    function get_user_feedbacks($uid) {
        if (!$uid)
            return NULL;

        /* id 	email  	uid feedback timestamp 	
         */
        $feedbacks = array();

        $table = 'user_feedback';
        $sql = "SELECT *  FROM   $table
			  WHERE  uid = '$uid'";

        $q = $this->db->query($sql);

        if ($q->num_rows()) {
            foreach ($q->result() as $row)
                $feedbacks[] = $row;
        }
        return $feedbacks;
    }

}
