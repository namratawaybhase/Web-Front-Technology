DROP DATABASE IF EXISTS computer_db;

CREATE DATABASE computer_db;

USE computer_db;
 
CREATE TABLE computers (
  computer_id           INT(11)        NOT NULL   AUTO_INCREMENT,
  computer_partnum             VARCHAR(20)    NOT NULL   UNIQUE,
  computer_name         VARCHAR(255)   NOT NULL,
  computer_quantity      INT(11)        NOT NULL,  
  computer_price        DECIMAL(10,2) NOT NULL,
  PRIMARY KEY (computer_id)
);

INSERT INTO computers VALUES
(1, '2394XE6', 'ThinkPad T530', '5', '1091.00'),
(2, '20BECTR1WW', 'ThinkPad T540p', '15', '1385.00'),
(3, '20ALX004US', 'ThinkPad X240', '25', '1600.00');


CREATE TABLE IF NOT EXISTS users (
  id int(11) NOT NULL AUTO_INCREMENT,
  user_name varchar(128) NOT NULL,
  password varchar(128) NOT NULL,
  role varchar(128) NOT NULL,
  PRIMARY KEY (id)
);

INSERT INTO users VALUES
(1, 'reg_user', 'abc', 'regular_user'),
(2, 'admin_user', 'abc', 'admin_user');

CREATE TABLE IF NOT EXISTS user_feedback (
  feedback_id int(11) NOT NULL AUTO_INCREMENT,
  uid      INT(11)        NOT NULL,
  feedback varchar(128) NOT NULL,
  PRIMARY KEY (feedback_id)
);

CREATE TABLE IF NOT EXISTS `ci_sessions` (
	`id` varchar(128) NOT NULL,
	`ip_address` varchar(45) NOT NULL,
	`timestamp` int(10) unsigned DEFAULT 0 NOT NULL,
	`data` blob NOT NULL,
	KEY `ci_sessions_timestamp` (`timestamp`)
);

GRANT SELECT, INSERT, DELETE, UPDATE
ON computer_db.*
TO admin@localhost
IDENTIFIED BY 'pass@word';


GRANT SELECT
ON computers
TO peter@localhost
IDENTIFIED BY 'pass@word';
